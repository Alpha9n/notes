echo "===js実行==="

echo "=====ex1:basicSyntax.js"
sleep 5
node ./ex1/basicSyntax.js
sleep 2

echo "=====ex2:breakAndContinue.js"
sleep 5
node ./ex2/breakAndContinue.js
sleep 2

echo "=====ex3:useNameAndAge.mjs"
sleep 5
node ./ex3/useNameAndAge.mjs
sleep 2

echo "=====ex4:calcFromRadius.mjs"
sleep 5
node ./ex4/calcFromRadius.mjs
sleep 2

echo "===終了==="
