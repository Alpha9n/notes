echo "===PHP実行==="

echo "\n=====ex1:basicSyntax.php"
sleep 5
php ./ex1/basicSyntax.php
sleep 2

echo "\n=====ex2:breakAndContinue.php"
sleep 5
php ./ex2/breakAndContinue.php
sleep 2

echo "\n=====ex3:useNameAndAge.php"
sleep 5
php ./ex3/useNameAndAge.php
sleep 2

echo "\n=====ex4:calcFromRadius.php"
sleep 5
php ./ex4/calcFromRadius.php
sleep 2

echo "===終了==="
